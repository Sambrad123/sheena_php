<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--<link rel="stylesheet" href="../assets/css/bootstrap/bootstrap-337.min.css">-->
    <link rel="stylesheet" href="../assets/css/gellish/gellish_import.css">
    <!--<link rel="stylesheet" href="../assets/fonts/font-awesome/css/font-awesome.min.css">-->
    <!--<link rel="stylesheet" href="../assets/css/custom/style.css">-->
</head>
<body bgcolor="red">
<div type="container">
    <h1 text-align="center" font-color="white" margin-top="100px">Connection Database Error</h1>
    <h2 text-align="center" font-color="white">Please check up your username & password</h2>
</div>
</body>
</html>